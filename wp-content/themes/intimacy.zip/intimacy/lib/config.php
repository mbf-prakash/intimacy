<?php
include('metabox/homepage_metabox.php');
include('metabox/myaccount_meta.php');
include('metabox/rightnav.php');
include('metabox/product-meta.php');
include('shortcode/shortcode.php');
include('post-types/portfolio.php');
include('post-types/locations.php');

?>
