<?php get_header(); ?>
<div class="container section-start nomobile">
				<div class="row">
					<div class="col-12">
						<div class="breadcrumbs clearfix">
							<ul>
								<li><a href="<?php echo get_site_url().'/'; ?>" title="Home">Home</a></li>
								<li><a href="#">Page Not found</a></li>
							</ul>
					</div>
					</div>
				</div>
			</div>
<div class="container generic-container generic-list">
					<div class="row">
						<div class="col-8">
							<div class="no-desc back-catagory"><a href="<?php echo get_site_url().'/'; ?>"><i class="fa fa-angle-left" aria-hidden="true"></i>Home</a></div>
							<h1>404 </h1>
							<h3>Looking for something?</h3>
							<p>We're sorry. The Web address you entered is not a functioning page on our site.</p>
 							<p>Go to <a href="<?php echo get_site_url().'/'; ?>">Intimacy</a> Home Page.</p>
          				    <div>&nbsp;</div>
						</div>
					</div>
				</div>
<?php get_footer();?>
