<?php
/**
 * The Template for displaying products in a product category. Simply includes the archive template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/taxonomy-product_cat.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<?php get_header();
$curr_term_id = get_queried_object()->term_id;
?>

<?php
$post_term=get_queried_object();
$product_cat_args = array('post_type' => 'product',
                                 'orderby'    => 'menu_order',
                              'order' => 'ASC',
			      'numberposts'=>-1,
                              'tax_query' =>  array(
                                      array(
                                          'taxonomy' => 'product_cat',
                                          'field' => 'id',
                                          'terms' => $curr_term_id
                                          )
                              )
                              );
$products = get_posts($product_cat_args);

?>

<div class="container generic-container no-desc">
				<div class="row shop-all">
					<div class="col-7">
						<div class="no-desc back-catagory"><a href="<?php echo get_bloginfo('url'); ?>/shop-all/"><i class="fa fa-angle-left" aria-hidden="true"></i>Shop All</a></div>
						<div class="breadcrumbs clearfix nomobile">
							<ul>
								<li><a href="<?php echo get_site_url().'/'; ?>" title="Home">Home</a></li>
								<li><a href="<?php echo get_bloginfo('url'); ?>/shop-all/" class="home">Shop all</a></li>
								<li><a href="#"><?php echo $post_term->name; ?></a></li>
							</ul>
					</div>
					<h1><?php echo $post_term->name; ?></h1>
					<?php echo wpautop($post_term->description); ?>
					</div>
				</div>
			</div>


			<div class="container intro-content nomobile">
				<div class="row">
					<div class="col-5 col-center-block">

						<div class="breadcrumbs clearfix nomobile">
							<ul>
								<li><a href="<?php echo get_site_url().'/'; ?>" title="Home">Home</a></li>
								<li><a href="<?php echo get_bloginfo('url'); ?>/shop-all/" class="home">Shop all</a></li>
								<li><a href="#"><?php echo $post_term->name; ?></a></li>
							</ul>
					</div>
					<h1><?php echo $post_term->name; ?></h1>
					<?php echo wpautop($post_term->description); ?>
					</div>
				</div>
			</div>

                <div class="container banner-card">

						<div class="row ">
							<div class="col-12 product-listing">
							<div class="Allcategories">
								<div class="row">
								
									<?php	
									$index=0;
									foreach ($products as $product) {
										//echo 'dd'; 
										if($index== 12){
											break;
									  }
								
												$feat_image = wp_get_attachment_url(get_post_thumbnail_id($product->ID));
										$secondry_Image=MultiPostThumbnails::get_post_thumbnail_url('product', 'secondary-image', $product->ID);

							?>
								
							<div class="col-3 productsortvalue productsort " data-sortvalue ="<?php echo $product->ID; ?>"  id="<?php echo $product->ID; ?>">	
							
															<a href="<?php echo get_permalink($product->ID); ?>" class="card no-effect thumbnail-wrapper">
																	<div class="image">
																			<img src="<?php echo $feat_image; ?>" alt="productimg" />
																		<?php if($secondry_Image !=''){?>
                                                   <span class="product-additional">
                                                     <img src="<?php echo $secondry_Image; ?>" alt="productimg" />
                                                   </span>
                                               <?php } ?>
																	</div>
																	<div class="card-content">
																			<h5><?php echo $product->post_title; ?></h5>
																			<?php
					                                    $var = new WC_Product_Variable( $product->ID );
					                                    $variations = $var->get_available_variations();
					                                        $variation_product_id = $variations [0]['variation_id'];
					                                    if(count($variations) != 0){
					                                        $variation_product = new WC_Product_Variation( $variation_product_id );
					                                        $var_reg_prc = $variation_product->regular_price;
					                                        $var_sal_prc = $variation_product->sale_price;

					                                    ?>
					                                    <h4>From<?php if($var_sal_prc!=''){ ?>₹<span><?php echo $var_sal_prc; ?><?php }else{ ?> ₹<?php echo $var_reg_prc; } ?></span></h4>
					                                    <?php

					                                     }else{

					                                        $reg_prc = get_post_meta( $product->ID, '_regular_price', true);
					                                        $sal_prc = get_post_meta( $product->ID, '_sale_price', true);
					                                        $price_show = $sal_prc == ''?$reg_prc:$sal_prc;
					                                        ?>
					                                        <h4>

					                                        <?php if($sal_prc!=''){ ?>
					                                        ₹<span class="unitprice"><?php echo $reg_prc; ?></span>
					                                         ₹<span><?php echo $sal_prc; ?><?php }else{ ?> ₹<?php echo $reg_prc; } ?>
					                                        </span>
					                                        </h4>
					                                    <?php } ?>
																	</div>
															</a>
													</div>
													 <?php 
													 $index++;
													 } 
													 
													 
													 ?>
													 
											</div>
											<input type="hidden" name='category'  id="curr_term_id"  value="<?php echo $curr_term_id;?>">
							</div>
							<input type="hidden" id="my-productjsone" value="" />
								<!-- Product listing section ends here -->
						</div>
						</div>
					</div>
<?php get_footer();?>

<script>

var sortProductsort=[];
  $(document).ready(function() {


  ///console.log('dd');
  $('.productsortvalue').each(function(){

		  currentFilterValues = $(this).data('sortvalue');
		 // console.log(currentFilterValues); 
		  if(currentFilterValues!=''){
			sortProductsort.push(currentFilterValues);
		  }else{
			  var id_val = this.value;
			  sortProductsort = jQuery.grep(sortProductsort, function(value) {
				  return value != id_val;
			  });
		  }
	  
	  });
	  var mysort_jsonssort =unique(sortProductsort);
	  //console.log(mysort_jsonssort);
	  mysort_jsonssort_value = JSON.stringify(mysort_jsonssort);
	  console.log(mysort_jsonssort_value);
	  $('#my-productjsone').val(mysort_jsonssort_value);
	  });


var processing = false;

	  $(window).scroll(function(e) {
		  e.preventDefault();
		  		var headerBottom = 6;

		//  console.log($('.allarea input[type="checkbox"]').is(':checked'));
		  //console.log($('.allarea input[type="checkbox"]').prop('checked'));
  
		  if($('.allarea input[type="checkbox"]').is(':checked')===true || $('.drop-item span').hasClass("active")===true || $('.color-variant-item').hasClass("active")== true){
			  // alert($('.drop-item span').hasClass("active"));
				  return false;
			  }
			if(($(window).scrollTop() >= headerBottom) && !processing ) {
				  processing = true;  					 
					//success.function(){processing = false;}
					var product_val=  $('#my-productjsone').val();
				//	console.log(product_val); 
				  var category_val = $('#curr_term_id').val();
				//  console.log(category_val);
				   $.ajax({
					  url: templateUri + "/ajax/productfilter-ajax.php",
					  type: 'POST',
					  data: {product_val: product_val,category_val:category_val},
					  success: function (result) {
						 // console.log(result);
						  var product_id= result.split('~');
						  //console.log(product_id); 
						  var json_rsp_id = product_id[1];
						
						  var filter_vals=product_val.split(',');
						  //console.log(filter_vals);
						  var product_ids=product_id['1'].split(',');
						  //console.log(product_ids);
						   processing = false;  
				
			
						  var objvalue_id=$.merge(  filter_vals , product_ids );
						 // console.log(objvalue_id);
			
						  //var objvalue = $.extend({},filter_val,json_rsp_id);
						  $('#my-productjsone').val(objvalue_id);
  
						  var last_list_item = $(document).find(".productsort:last").attr('id');
						 // console.log(last_list_item); 
						  $(document).find(".productsort:last").after(product_id['0']);
						  $(document).find(".listItem:last");
						  if(result[0].trim() == ''){
  
						  return false;
						  }
						  //		$('#productid').html();
						  //('#product_id').html(json_rsp_id);
					  }
				   });
			  }
		  });
	  

</script>